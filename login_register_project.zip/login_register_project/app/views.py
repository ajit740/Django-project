from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from .models import UserRegister
from django.contrib import messages
from django.contrib.auth.decorators import login_required


from django.contrib.auth import login,logout,authenticate

# Create your views here.

def home_page(request):
    all_data = UserRegister.objects.all()
    context = {
        'all_users':all_data
    }
    return render(request,'home.html',context)

def register(request):
    if request.method == 'POST':
        user_name = request.POST.get('user_name')
        first_name = request.POST.get('fname')
        last_name = request.POST.get('lname')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')
        address = request.POST.get('address')
        password = request.POST.get('password')

        user_obj = User.objects.create_user(username = user_name,first_name = first_name,last_name = last_name,email = email,password = password)
        print(user_obj.first_name,'UUUUUUUUUUU')
        UserRegister(user = user_obj,mobile_number = mobile,address = address).save()
        
        messages.success(request,'User Successfully Registerd')
        return render(request,'register.html')
    return render(request,'register.html')

def user_login(request):

    if request.method == 'POST':
        user_name = request.POST.get('user_name')
        password = request.POST.get('password')
        
        user = authenticate(username = user_name,password = password)

        if user is not None:
            login(request,user)
            messages.success(request,'User Successfully Login')
            return redirect('/')
        else:
             return render(request,'login.html')
    return render(request,'login.html')

def user_logout(request):
    user = request.user
    logout(request)
    return redirect('/')